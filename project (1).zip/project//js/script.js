<script>
    document.getElementById("registerForm").addEventListener("submit", function(e) {
        e.preventDefault();

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const phone = document.getElementById("phone").value;
        const birthdate = document.getElementById("birthdate").value;
        const password = document.getElementById("password").value;
        const gender = document.querySelector("input[name='gender']:checked").value;

        const user = {
            name: name,
            email: email,
            phone: phone,
            birthdate: birthdate,
            password: password,
            gender: gender,
        };

        // Simpan ke localStorage (opsional)
        localStorage.setItem(email, JSON.stringify(user));

        // Tambah data ke tabel
        const table = document.getElementById("dataTable").getElementsByTagName('tbody')[0];
        const newRow = table.insertRow();

        newRow.insertCell().textContent = name;
        newRow.insertCell().textContent = email;
        newRow.insertCell().textContent = phone;
        newRow.insertCell().textContent = birthdate;
        newRow.insertCell().textContent = gender;

        // Reset form
        document.getElementById("registerForm").reset();
        
        // Alert
        alert("keren guis");
    });
</script>